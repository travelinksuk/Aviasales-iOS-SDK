#import <Foundation/Foundation.h>

@interface NSString (HLCapitalization)

- (NSString *)hl_firstLetterCapitalizedString;

@end
