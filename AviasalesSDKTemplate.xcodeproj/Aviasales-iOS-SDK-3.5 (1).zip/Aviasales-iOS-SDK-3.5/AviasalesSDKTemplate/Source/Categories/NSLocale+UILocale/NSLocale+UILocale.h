//
//  NSLocale+UILocale.h
//  AviasalesSDKTemplate
//
//  Created by Dim on 28.06.2018.
//  Copyright © 2018 Go Travel Un Limited. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSLocale (UILocale)

+ (NSLocale *)applicationUILocale;

@end
