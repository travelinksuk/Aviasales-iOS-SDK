#import <Foundation/Foundation.h>

@interface NSArray (HLContentComparison)

- (BOOL)hl_isContentEqualToArray:(NSArray *)array;

@end
