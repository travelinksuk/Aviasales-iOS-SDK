#import <UIKit/UIKit.h>

@interface UIViewController (UIScrollView)

- (void)setScrollViewTouchableArea:(UIScrollView *)scrollView;

@end
