#import <UIKit/UIKit.h>

@interface UIScrollView (ScrollableArea)

- (void)hl_setScrollableAreaToView:(UIView *)view;

@end
