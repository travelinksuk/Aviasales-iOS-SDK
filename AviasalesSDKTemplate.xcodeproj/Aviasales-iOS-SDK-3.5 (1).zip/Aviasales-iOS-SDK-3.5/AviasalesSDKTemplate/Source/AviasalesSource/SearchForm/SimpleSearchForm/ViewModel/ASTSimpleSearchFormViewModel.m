//
//  ASTSimpleSearchFormViewModel.m
//
//  Copyright 2016 Go Travel Un Limited
//  This code is distributed under the terms and conditions of the MIT license.
//

#import "ASTSimpleSearchFormViewModel.h"


@implementation ASTSimpleSearchFormCellViewModel

@end


@implementation ASTSimpleSearchFormAirportCellViewModel

@end


@implementation ASTSimpleSearchFormDateCellViewModel

@end


@implementation ASTSimpleSearchFormSectionViewModel

@end


@implementation ASTSimpleSearchFormPassengersViewModel

@end


@implementation ASTSimpleSearchFormViewModel

@end
