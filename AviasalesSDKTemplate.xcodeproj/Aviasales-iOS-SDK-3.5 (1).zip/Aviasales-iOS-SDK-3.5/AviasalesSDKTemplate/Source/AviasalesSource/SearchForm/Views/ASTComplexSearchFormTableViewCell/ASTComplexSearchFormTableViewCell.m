//
//  ASTComplexSearchFormTableViewCell.m
//
//  Copyright 2016 Go Travel Un Limited
//  This code is distributed under the terms and conditions of the MIT license.
//

#import "ASTComplexSearchFormTableViewCell.h"

@implementation ASTComplexSearchFormTableViewCell

@end
