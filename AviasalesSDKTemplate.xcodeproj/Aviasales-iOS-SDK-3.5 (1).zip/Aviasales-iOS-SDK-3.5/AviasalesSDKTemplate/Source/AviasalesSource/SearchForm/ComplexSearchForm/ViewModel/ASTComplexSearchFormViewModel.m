//
//  ASTComplexSearchFormViewModel.m
//
//  Copyright 2016 Go Travel Un Limited
//  This code is distributed under the terms and conditions of the MIT license.
//

#import "ASTComplexSearchFormViewModel.h"


@implementation ASTComplexSearchFormCellSegmentViewModel

@end


@implementation ASTComplexSearchFormCellViewModel

@end


@implementation ASTComplexSearchFormFooterViewModel

@end


@implementation ASTComplexSearchFormPassengersViewModel

@end


@implementation ASTComplexSearchFormViewModel

@end
