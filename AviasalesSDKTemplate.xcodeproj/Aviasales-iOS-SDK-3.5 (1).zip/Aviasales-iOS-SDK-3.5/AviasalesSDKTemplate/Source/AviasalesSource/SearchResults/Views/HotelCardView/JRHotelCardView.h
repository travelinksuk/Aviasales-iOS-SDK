//
//  JRHotelCardView.h
//  AviasalesSDKTemplate
//
//  Created by Dim on 14.06.17.
//  Copyright © 2017 Go Travel Un Limited. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JRHotelCardView : UIView

@property (nonatomic, copy) void (^buttonAction)(void);

@end
