//
//  InfoScreenIconImageViewFiveTimesTapHandler.swift
//  AviasalesSDKTemplate
//
//  Created by Dim on 13.02.2018.
//  Copyright © 2018 Go Travel Un LImited. All rights reserved.
//

protocol InfoScreenIconImageViewFiveTimesTapHandler {
    func handleFiveTimesTap()
}

extension InfoScreenIconImageViewFiveTimesTapHandler {
    func handleFiveTimesTap() {}
}

